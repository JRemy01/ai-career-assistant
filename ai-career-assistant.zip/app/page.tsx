"use client"

import { useState } from "react"
import { ChatInterface } from "@/components/chat-interface"
import { QuizzesTab } from "@/components/quizzes-tab"
import { ProgressTab } from "@/components/progress-tab"
import { CoursesTab } from "@/components/courses-tab"
import { JobsEventsTab } from "@/components/jobs-events-tab"
import { Sidebar } from "@/components/sidebar"

export default function Home() {
  const [activeTab, setActiveTab] = useState<"chat" | "quizzes" | "progress" | "courses" | "jobs">("chat")

  return (
    <div className="flex h-screen bg-background">
      <Sidebar activeTab={activeTab} onTabChange={setActiveTab} />

      <main className="flex-1 overflow-hidden">
        {activeTab === "chat" && <ChatInterface />}
        {activeTab === "quizzes" && <QuizzesTab />}
        {activeTab === "progress" && <ProgressTab />}
        {activeTab === "courses" && <CoursesTab />}
        {activeTab === "jobs" && <JobsEventsTab />}
      </main>
    </div>
  )
}
