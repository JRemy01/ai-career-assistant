"use client"

import { useState } from "react"
import { MapPin, ExternalLink, Calendar, Briefcase } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

const jobs = [
  {
    id: 1,
    title: "Junior Data Scientist",
    company: "TechCorp AI",
    location: "Remote",
    type: "Full-time",
  },
  {
    id: 2,
    title: "Machine Learning Engineer",
    company: "DataFlow Inc",
    location: "San Francisco, CA",
    type: "Full-time",
  },
  {
    id: 3,
    title: "Data Analyst Intern",
    company: "Analytics Pro",
    location: "New York, NY",
    type: "Internship",
  },
  {
    id: 4,
    title: "AI Research Scientist",
    company: "DeepMind Labs",
    location: "Remote",
    type: "Full-time",
  },
]

const events = [
  {
    id: 1,
    title: "AI Summit 2025",
    organizer: "AI Conference Group",
    date: "March 15-17, 2025",
    location: "Virtual",
  },
  {
    id: 2,
    title: "Data Science Bootcamp",
    organizer: "Learn Data Academy",
    date: "April 1, 2025",
    location: "Boston, MA",
  },
  {
    id: 3,
    title: "Machine Learning Workshop",
    organizer: "Tech Education Hub",
    date: "March 28, 2025",
    location: "Virtual",
  },
  {
    id: 4,
    title: "Career Fair: Tech & AI",
    organizer: "Career Connect",
    date: "April 10, 2025",
    location: "Seattle, WA",
  },
]

export function JobsEventsTab() {
  const [filter, setFilter] = useState<"all" | "remote" | "onsite">("all")

  const filteredJobs = jobs.filter((job) => {
    if (filter === "all") return true
    if (filter === "remote") return job.location === "Remote"
    return job.location !== "Remote"
  })

  return (
    <div className="flex flex-col h-full overflow-y-auto">
      <header className="border-b border-border bg-card px-6 py-4">
        <h2 className="text-lg font-semibold text-foreground">Jobs & Events</h2>
        <p className="text-sm text-muted-foreground">Discover opportunities and networking events</p>
      </header>

      <div className="p-6">
        <Tabs defaultValue="jobs" className="w-full">
          <TabsList className="grid w-full max-w-md grid-cols-2 mb-6">
            <TabsTrigger value="jobs">Job Openings</TabsTrigger>
            <TabsTrigger value="events">Events</TabsTrigger>
          </TabsList>

          <TabsContent value="jobs" className="space-y-4">
            <div className="flex gap-2 mb-4">
              <Button variant={filter === "all" ? "default" : "outline"} size="sm" onClick={() => setFilter("all")}>
                All
              </Button>
              <Button
                variant={filter === "remote" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilter("remote")}
              >
                Remote
              </Button>
              <Button
                variant={filter === "onsite" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilter("onsite")}
              >
                On-site
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredJobs.map((job) => (
                <div
                  key={job.id}
                  className="bg-card border border-border rounded-xl p-6 hover:shadow-lg transition-shadow"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-semibold text-foreground text-lg">{job.title}</h3>
                      <p className="text-sm text-muted-foreground mt-1">{job.company}</p>
                    </div>
                    <Badge variant="secondary">
                      <Briefcase className="w-3 h-3 mr-1" />
                      {job.type}
                    </Badge>
                  </div>

                  <div className="flex items-center gap-2 mb-4 text-sm text-muted-foreground">
                    <MapPin className="w-4 h-4" />
                    <span>{job.location}</span>
                  </div>

                  <Button size="sm" className="w-full">
                    Apply Now
                    <ExternalLink className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="events" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {events.map((event) => (
                <div
                  key={event.id}
                  className="bg-card border border-border rounded-xl p-6 hover:shadow-lg transition-shadow"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-semibold text-foreground text-lg">{event.title}</h3>
                      <p className="text-sm text-muted-foreground mt-1">{event.organizer}</p>
                    </div>
                    <Badge variant="secondary">Event</Badge>
                  </div>

                  <div className="space-y-2 mb-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      <span>{event.date}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4" />
                      <span>{event.location}</span>
                    </div>
                  </div>

                  <Button size="sm" className="w-full">
                    Register
                    <ExternalLink className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
