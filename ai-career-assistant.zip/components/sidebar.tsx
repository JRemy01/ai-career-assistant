"use client"

import { MessageSquare, FileQuestion, TrendingUp, GraduationCap, Briefcase } from "lucide-react"
import { cn } from "@/lib/utils"

interface SidebarProps {
  activeTab: "chat" | "quizzes" | "progress" | "courses" | "jobs"
  onTabChange: (tab: "chat" | "quizzes" | "progress" | "courses" | "jobs") => void
}

const tabs = [
  { id: "chat" as const, label: "Chat", icon: MessageSquare },
  { id: "quizzes" as const, label: "Quizzes", icon: FileQuestion },
  { id: "progress" as const, label: "Progress", icon: TrendingUp },
  { id: "courses" as const, label: "Courses", icon: GraduationCap },
  { id: "jobs" as const, label: "Jobs & Events", icon: Briefcase },
]

export function Sidebar({ activeTab, onTabChange }: SidebarProps) {
  return (
    <aside className="w-64 border-r border-border bg-card flex flex-col">
      <div className="p-6 border-b border-border">
        <h1 className="text-xl font-semibold text-foreground">AI Career Assistant</h1>
        <p className="text-sm text-muted-foreground mt-1">Learn Data & AI Skills</p>
      </div>

      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {tabs.map((tab) => {
            const Icon = tab.icon
            return (
              <li key={tab.id}>
                <button
                  onClick={() => onTabChange(tab.id)}
                  className={cn(
                    "w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors",
                    activeTab === tab.id ? "bg-primary text-primary-foreground" : "text-foreground hover:bg-secondary",
                  )}
                >
                  <Icon className="w-5 h-5" />
                  {tab.label}
                </button>
              </li>
            )
          })}
        </ul>
      </nav>

      <div className="p-4 border-t border-border">
        <div className="bg-secondary rounded-lg p-4">
          <p className="text-sm font-medium text-foreground">Need help?</p>
          <p className="text-xs text-muted-foreground mt-1">Ask me anything about Data Science and AI careers!</p>
        </div>
      </div>
    </aside>
  )
}
