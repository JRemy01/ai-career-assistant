import { ExternalLink, Clock, BarChart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

const courses = [
  {
    id: 1,
    title: "Machine Learning Fundamentals",
    description: "Learn the basics of ML algorithms, model training, and evaluation techniques.",
    duration: "8 weeks",
    difficulty: "Intermediate",
    platform: "Coursera",
    isPaid: false,
  },
  {
    id: 2,
    title: "Deep Learning Specialization",
    description: "Master neural networks, CNNs, RNNs, and transformers with hands-on projects.",
    duration: "12 weeks",
    difficulty: "Advanced",
    platform: "DeepLearning.AI",
    isPaid: true,
  },
  {
    id: 3,
    title: "Python for Data Science",
    description: "Complete guide to Python programming for data analysis and visualization.",
    duration: "6 weeks",
    difficulty: "Beginner",
    platform: "edX",
    isPaid: false,
  },
  {
    id: 4,
    title: "SQL for Data Analysis",
    description: "Master SQL queries, joins, aggregations, and database design principles.",
    duration: "4 weeks",
    difficulty: "Beginner",
    platform: "Udacity",
    isPaid: false,
  },
  {
    id: 5,
    title: "Natural Language Processing",
    description: "Learn text processing, sentiment analysis, and language models.",
    duration: "10 weeks",
    difficulty: "Advanced",
    platform: "Coursera",
    isPaid: true,
  },
  {
    id: 6,
    title: "Data Visualization with Tableau",
    description: "Create stunning dashboards and tell stories with data visualization.",
    duration: "5 weeks",
    difficulty: "Intermediate",
    platform: "Tableau",
    isPaid: false,
  },
]

export function CoursesTab() {
  return (
    <div className="flex flex-col h-full overflow-y-auto">
      <header className="border-b border-border bg-card px-6 py-4">
        <h2 className="text-lg font-semibold text-foreground">Recommended Courses</h2>
        <p className="text-sm text-muted-foreground">Personalized learning paths for your career goals</p>
      </header>

      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {courses.map((course) => (
            <div
              key={course.id}
              className="bg-card border border-border rounded-xl p-6 hover:shadow-lg transition-shadow"
            >
              <div className="flex items-start justify-between mb-3">
                <h3 className="font-semibold text-foreground text-lg">{course.title}</h3>
                <Badge variant={course.isPaid ? "default" : "secondary"}>{course.isPaid ? "Paid" : "Free"}</Badge>
              </div>

              <p className="text-sm text-muted-foreground mb-4 leading-relaxed">{course.description}</p>

              <div className="flex items-center gap-4 mb-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-1.5">
                  <Clock className="w-4 h-4" />
                  <span>{course.duration}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <BarChart className="w-4 h-4" />
                  <span>{course.difficulty}</span>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Platform: {course.platform}</span>
                <Button size="sm">
                  Start Learning
                  <ExternalLink className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
