"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Check, X, ChevronRight } from "lucide-react"
import { cn } from "@/lib/utils"

const quizQuestions = [
  {
    question: "What does SQL stand for?",
    options: ["Structured Query Language", "Simple Question Language", "System Quality Logic", "Standard Query List"],
    correctAnswer: 0,
    explanation: "SQL stands for Structured Query Language, used for managing and querying relational databases.",
  },
  {
    question: "Which Python library is primarily used for data manipulation?",
    options: ["NumPy", "Pandas", "Matplotlib", "Scikit-learn"],
    correctAnswer: 1,
    explanation:
      "Pandas is the primary library for data manipulation and analysis in Python, providing DataFrames and Series.",
  },
  {
    question: "What is overfitting in machine learning?",
    options: [
      "When a model performs poorly on training data",
      "When a model learns training data too well and fails on new data",
      "When a model is too simple",
      "When a model has too few parameters",
    ],
    correctAnswer: 1,
    explanation:
      "Overfitting occurs when a model learns the training data too well, including noise, and fails to generalize to new data.",
  },
  {
    question: "What is the purpose of a confusion matrix?",
    options: [
      "To confuse data scientists",
      "To visualize model performance on classification tasks",
      "To store training data",
      "To optimize hyperparameters",
    ],
    correctAnswer: 1,
    explanation:
      "A confusion matrix visualizes the performance of a classification model by showing true vs predicted classifications.",
  },
  {
    question: "Which algorithm is best for finding patterns in unlabeled data?",
    options: ["Linear Regression", "Decision Trees", "K-Means Clustering", "Logistic Regression"],
    correctAnswer: 2,
    explanation:
      "K-Means Clustering is an unsupervised learning algorithm used to find patterns and group similar data points in unlabeled data.",
  },
]

export function QuizzesTab() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [showExplanation, setShowExplanation] = useState(false)
  const [score, setScore] = useState(0)
  const [quizComplete, setQuizComplete] = useState(false)

  const progress = ((currentQuestion + 1) / quizQuestions.length) * 100

  const handleAnswer = (index: number) => {
    setSelectedAnswer(index)
    setShowExplanation(true)
    if (index === quizQuestions[currentQuestion].correctAnswer) {
      setScore(score + 1)
    }
  }

  const handleNext = () => {
    if (currentQuestion < quizQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
      setSelectedAnswer(null)
      setShowExplanation(false)
    } else {
      setQuizComplete(true)
    }
  }

  const handleRestart = () => {
    setCurrentQuestion(0)
    setSelectedAnswer(null)
    setShowExplanation(false)
    setScore(0)
    setQuizComplete(false)
  }

  if (quizComplete) {
    return (
      <div className="flex flex-col h-full items-center justify-center p-6">
        <div className="bg-card border border-border rounded-xl p-8 max-w-md w-full text-center">
          <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
            <Check className="w-8 h-8 text-primary-foreground" />
          </div>
          <h2 className="text-2xl font-bold text-foreground mb-2">Quiz Complete!</h2>
          <p className="text-muted-foreground mb-6">
            You scored {score} out of {quizQuestions.length}
          </p>
          <div className="mb-6">
            <div className="text-4xl font-bold text-primary mb-2">
              {Math.round((score / quizQuestions.length) * 100)}%
            </div>
            <p className="text-sm text-muted-foreground">
              {score === quizQuestions.length
                ? "Perfect score! Outstanding!"
                : score >= quizQuestions.length * 0.7
                  ? "Great job! Keep it up!"
                  : "Good effort! Review the topics and try again."}
            </p>
          </div>
          <Button onClick={handleRestart} className="w-full">
            Take Quiz Again
          </Button>
        </div>
      </div>
    )
  }

  const question = quizQuestions[currentQuestion]

  return (
    <div className="flex flex-col h-full">
      <header className="border-b border-border bg-card px-6 py-4">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold text-foreground">Data Science Quiz</h2>
          <span className="text-sm text-muted-foreground">
            Question {currentQuestion + 1} of {quizQuestions.length}
          </span>
        </div>
        <Progress value={progress} className="h-2" />
      </header>

      <div className="flex-1 overflow-y-auto p-6 flex items-center justify-center">
        <div className="max-w-2xl w-full">
          <h3 className="text-xl font-semibold text-foreground mb-6">{question.question}</h3>

          <div className="space-y-3 mb-6">
            {question.options.map((option, index) => {
              const isSelected = selectedAnswer === index
              const isCorrect = index === question.correctAnswer
              const showFeedback = showExplanation

              return (
                <button
                  key={index}
                  onClick={() => !showExplanation && handleAnswer(index)}
                  disabled={showExplanation}
                  className={cn(
                    "w-full text-left px-6 py-4 rounded-xl border-2 transition-all",
                    !showFeedback && "border-border hover:border-primary hover:bg-secondary",
                    showFeedback && isCorrect && "border-success bg-success/10",
                    showFeedback && isSelected && !isCorrect && "border-destructive bg-destructive/10",
                    showFeedback && !isSelected && !isCorrect && "border-border opacity-50",
                  )}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-foreground">{option}</span>
                    {showFeedback && isCorrect && <Check className="w-5 h-5 text-success" />}
                    {showFeedback && isSelected && !isCorrect && <X className="w-5 h-5 text-destructive" />}
                  </div>
                </button>
              )
            })}
          </div>

          {showExplanation && (
            <div className="space-y-4 animate-in fade-in slide-in-from-top-2 duration-300">
              <div className="p-4 bg-secondary rounded-xl">
                <p className="text-sm text-foreground">
                  <span className="font-medium">Explanation: </span>
                  {question.explanation}
                </p>
              </div>
              <Button onClick={handleNext} className="w-full">
                {currentQuestion < quizQuestions.length - 1 ? "Next Question" : "Finish Quiz"}
                <ChevronRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
