"use client"

import { TrendingUp, TrendingDown } from "lucide-react"
import { Progress } from "@/components/ui/progress"

const skillsData = [
  { name: "Python", level: 85, trend: "up" },
  { name: "SQL", level: 72, trend: "up" },
  { name: "Statistics", level: 58, trend: "down" },
  { name: "Machine Learning", level: 68, trend: "up" },
  { name: "Data Visualization", level: 75, trend: "up" },
  { name: "Deep Learning", level: 45, trend: "up" },
]

export function ProgressTab() {
  const strongest = skillsData.reduce((max, skill) => (skill.level > max.level ? skill : max))
  const weakest = skillsData.reduce((min, skill) => (skill.level < min.level ? skill : min))

  return (
    <div className="flex flex-col h-full overflow-y-auto">
      <header className="border-b border-border bg-card px-6 py-4">
        <h2 className="text-lg font-semibold text-foreground">Your Progress</h2>
        <p className="text-sm text-muted-foreground">Track your skill development</p>
      </header>

      <div className="p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-card border border-border rounded-xl p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 bg-success/10 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-success" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Strongest Skill</p>
                <p className="font-semibold text-foreground">{strongest.name}</p>
              </div>
            </div>
            <div className="mt-4">
              <Progress value={strongest.level} className="h-2" />
              <p className="text-xs text-muted-foreground mt-2">{strongest.level}% proficiency</p>
            </div>
          </div>

          <div className="bg-card border border-border rounded-xl p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center">
                <TrendingDown className="w-5 h-5 text-accent" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Focus Area</p>
                <p className="font-semibold text-foreground">{weakest.name}</p>
              </div>
            </div>
            <div className="mt-4">
              <Progress value={weakest.level} className="h-2" />
              <p className="text-xs text-muted-foreground mt-2">{weakest.level}% proficiency</p>
            </div>
          </div>
        </div>

        <div className="bg-card border border-border rounded-xl p-6">
          <h3 className="font-semibold text-foreground mb-4">Skills Overview</h3>
          <div className="space-y-4">
            {skillsData.map((skill) => (
              <div key={skill.name}>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-foreground">{skill.name}</span>
                    {skill.trend === "up" ? (
                      <TrendingUp className="w-4 h-4 text-success" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-destructive" />
                    )}
                  </div>
                  <span className="text-sm text-muted-foreground">{skill.level}%</span>
                </div>
                <Progress value={skill.level} className="h-2" />
              </div>
            ))}
          </div>
        </div>

        <div className="bg-secondary rounded-xl p-6">
          <h3 className="font-semibold text-foreground mb-2">Performance Summary</h3>
          <p className="text-sm text-muted-foreground leading-relaxed">
            You're strongest in <span className="font-medium text-foreground">{strongest.name}</span> and should focus
            on improving your <span className="font-medium text-foreground">{weakest.name}</span> skills. Keep up the
            great work! You've shown consistent improvement across most areas.
          </p>
        </div>
      </div>
    </div>
  )
}
