"use client"

import { useState, useRef, useEffect } from "react"
import { Send, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ChatMessage } from "@/components/chat-message"
import { QuizCard } from "@/components/quiz-card"
import { CourseCard } from "@/components/course-card"
import { JobCard } from "@/components/job-card"

interface Message {
  id: string
  type: "user" | "bot"
  content: string
  cardType?: "quiz" | "course" | "job"
  cardData?: any
}

const initialMessages: Message[] = [
  {
    id: "1",
    type: "bot",
    content:
      "Hi! I'm your AI Career Assistant. I'm here to help you learn Data & AI skills, take quizzes, and find the best courses and opportunities. What would you like to explore today?",
  },
]

export function ChatInterface() {
  const [messages, setMessages] = useState<Message[]>(initialMessages)
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages, isTyping])

  const handleSend = async () => {
    if (!input.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      type: "user",
      content: input,
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsTyping(true)

    // Simulate bot response
    setTimeout(() => {
      const botResponse = generateBotResponse(input)
      setMessages((prev) => [...prev, botResponse])
      setIsTyping(false)
    }, 1500)
  }

  const generateBotResponse = (userInput: string): Message => {
    const lowerInput = userInput.toLowerCase()

    if (lowerInput.includes("quiz") || lowerInput.includes("test")) {
      return {
        id: Date.now().toString(),
        type: "bot",
        content: "Great! Let's test your knowledge with a quick quiz:",
        cardType: "quiz",
        cardData: {
          question: "What is the primary purpose of a neural network?",
          options: [
            "To store data efficiently",
            "To learn patterns from data",
            "To replace databases",
            "To create user interfaces",
          ],
          correctAnswer: 1,
          explanation:
            "Neural networks are designed to learn patterns and relationships from data, mimicking how the human brain processes information.",
        },
      }
    }

    if (lowerInput.includes("course") || lowerInput.includes("learn")) {
      return {
        id: Date.now().toString(),
        type: "bot",
        content: "I found some excellent courses for you:",
        cardType: "course",
        cardData: {
          title: "Machine Learning Fundamentals",
          description: "Learn the basics of ML algorithms, model training, and evaluation techniques.",
          duration: "8 weeks",
          difficulty: "Intermediate",
          platform: "Coursera",
          isPaid: false,
        },
      }
    }

    if (lowerInput.includes("job") || lowerInput.includes("career")) {
      return {
        id: Date.now().toString(),
        type: "bot",
        content: "Here's an exciting opportunity I found:",
        cardType: "job",
        cardData: {
          title: "Junior Data Scientist",
          company: "TechCorp AI",
          location: "Remote",
          type: "job",
        },
      }
    }

    return {
      id: Date.now().toString(),
      type: "bot",
      content:
        "I can help you with quizzes, course recommendations, job opportunities, and career advice in Data Science and AI. What would you like to explore?",
    }
  }

  return (
    <div className="flex flex-col h-full">
      <header className="border-b border-border bg-card px-6 py-4">
        <h2 className="text-lg font-semibold text-foreground">Chat Assistant</h2>
        <p className="text-sm text-muted-foreground">Ask me anything about your AI career journey</p>
      </header>

      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {messages.map((message) => (
          <div key={message.id}>
            <ChatMessage message={message} />
            {message.cardType === "quiz" && message.cardData && (
              <div className="mt-4 ml-12">
                <QuizCard {...message.cardData} />
              </div>
            )}
            {message.cardType === "course" && message.cardData && (
              <div className="mt-4 ml-12">
                <CourseCard {...message.cardData} />
              </div>
            )}
            {message.cardType === "job" && message.cardData && (
              <div className="mt-4 ml-12">
                <JobCard {...message.cardData} />
              </div>
            )}
          </div>
        ))}

        {isTyping && (
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground text-sm font-medium">
              AI
            </div>
            <div className="bg-card border border-border rounded-2xl px-4 py-3 max-w-2xl">
              <div className="flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
                <span className="text-sm text-muted-foreground">Thinking...</span>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      <div className="border-t border-border bg-card p-6">
        <div className="flex gap-3">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
            placeholder="Ask about courses, quizzes, jobs, or career advice..."
            className="flex-1"
          />
          <Button onClick={handleSend} disabled={!input.trim()}>
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}
